$(document).ready(function() {
    $('#example1form').submit(function(evt){
        var msgTitle = $('#message-title').val();
        var msgBody = $('#message').val();
        oPush = {
            title: msgTitle,
            body: msgBody
        }
        PushBullet.push("note", null, null, oPush, function(err, res){
            var response = "";
            if(err) {
                response = "Error: " + err;
            } else {
                response = JSON.stringify(res, null, 4);
            }
            $('#responses').html("<pre>" + response + "</pre>");
            $('#response-holder').slideDown();
        });
        evt.preventDefault();
    });
});